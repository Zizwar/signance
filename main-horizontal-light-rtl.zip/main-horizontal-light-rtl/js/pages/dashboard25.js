//[Dashboard Javascript]

//Project:	Crypto Admin - Responsive Admin Template
//Primary use:   Used only for the main dashboard (index.html)


$(function () {

  'use strict';	


	//ticker

		if ($('#webticker-7').length) {   
			$("#webticker-7").webTicker({
				height:'auto', 
				duplicate:true,
				startEmpty:false, 
				rssfrequency:5,
			});
		}
	
	
}); // End of use strict




                


