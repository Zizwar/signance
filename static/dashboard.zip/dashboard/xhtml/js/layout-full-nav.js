(function($) {
    "use strict"

    new dzSettings({
        sidebarStyle: "full", 
    });


})(jQuery);