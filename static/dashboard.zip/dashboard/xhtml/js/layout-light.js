(function($) {
    "use strict"

    new dzSettings({
        version: "light"
    });


})(jQuery);